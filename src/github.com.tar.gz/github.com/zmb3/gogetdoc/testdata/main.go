package main

import "github.com/zmb3/vp"

func main() {
	vp.Hello()
}
