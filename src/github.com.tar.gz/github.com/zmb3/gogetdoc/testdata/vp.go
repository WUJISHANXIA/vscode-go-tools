// Package vp is an exmaple vendored package.
package vp

import "fmt"

// Hello says hello.
func Hello() {
	fmt.Println("Hello")
}
