package testdata

import "go/types"

func (i *Importer) Foo35(t types.Type) *types.Var {
	return nil
}
