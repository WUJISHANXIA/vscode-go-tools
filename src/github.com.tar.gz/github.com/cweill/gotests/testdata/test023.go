package testdata

func Foo23(ch chan bool) chan string { return make(chan string) }
