package testdata

func Foo102(s string) string {
	return ""
}
