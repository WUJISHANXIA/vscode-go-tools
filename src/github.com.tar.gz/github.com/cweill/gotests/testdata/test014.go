package testdata

func Foo14(f func(string, int) string) error { return nil }
