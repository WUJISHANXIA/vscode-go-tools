package testdata

import "io"

func Foo17(r io.Reader) io.Reader { return r }
